package com.wadlab.academy_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademyBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademyBankApplication.class, args);
	}

}
