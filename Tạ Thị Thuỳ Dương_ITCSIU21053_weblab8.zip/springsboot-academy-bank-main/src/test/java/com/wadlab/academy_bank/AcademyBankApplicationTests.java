package com.wadlab.academy_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademyBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
